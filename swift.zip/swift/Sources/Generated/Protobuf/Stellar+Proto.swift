// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

public typealias StellarAsset = TW_Stellar_Proto_Asset
public typealias StellarOperationCreateAccount = TW_Stellar_Proto_OperationCreateAccount
public typealias StellarOperationPayment = TW_Stellar_Proto_OperationPayment
public typealias StellarOperationChangeTrust = TW_Stellar_Proto_OperationChangeTrust
public typealias StellarClaimant = TW_Stellar_Proto_Claimant
public typealias StellarOperationCreateClaimableBalance = TW_Stellar_Proto_OperationCreateClaimableBalance
public typealias StellarOperationClaimClaimableBalance = TW_Stellar_Proto_OperationClaimClaimableBalance
public typealias StellarMemoVoid = TW_Stellar_Proto_MemoVoid
public typealias StellarMemoText = TW_Stellar_Proto_MemoText
public typealias StellarMemoId = TW_Stellar_Proto_MemoId
public typealias StellarMemoHash = TW_Stellar_Proto_MemoHash
public typealias StellarSigningInput = TW_Stellar_Proto_SigningInput
public typealias StellarSigningOutput = TW_Stellar_Proto_SigningOutput
public typealias StellarClaimPredicate = TW_Stellar_Proto_ClaimPredicate
